// Phylax SafeGuard — Popup Script
// Minimal: just confirms the extension is running.
// Rules and settings are not shown to the child.
